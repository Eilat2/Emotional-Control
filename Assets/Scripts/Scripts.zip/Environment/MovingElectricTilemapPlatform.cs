using UnityEngine;

public class MovingElectricTilemapPlatform : MonoBehaviour
{
    [Header("����� ��� ����")]
    [SerializeField] private Transform leftTargetPoint;

    [Header("����� ��� ����")]
    [SerializeField] private Transform rightTargetPoint;

    [Header("������ �����")]
    [SerializeField] private float moveSpeed = 2f;

    [Header("��� ������ ������ ����")]
    [SerializeField] private bool startMovingRight = true;

    private Transform currentTarget;
    private float startY;

    private void Start()
    {
        startY = transform.position.y;
        currentTarget = startMovingRight ? rightTargetPoint : leftTargetPoint;
    }

    private void Update()
    {
        if (leftTargetPoint == null || rightTargetPoint == null)
            return;

        Vector3 targetPosition = new Vector3(
            currentTarget.position.x,
            startY,
            transform.position.z
        );

        transform.position = Vector3.MoveTowards(
            transform.position,
            targetPosition,
            moveSpeed * Time.deltaTime
        );

        if (Mathf.Abs(transform.position.x - currentTarget.position.x) < 0.05f)
        {
            currentTarget = currentTarget == rightTargetPoint
                ? leftTargetPoint
                : rightTargetPoint;
        }
    }
}