using UnityEngine;

// �������� �� ��� ������:
// - ����� �����/����� ����
// - Space �� ���� ����
// - �� ������ ���� ������ -> Game Over �����
// - ����� �������� Idle / Walk / Fall
public class NeutralEmotionStrategy : MonoBehaviour, IEmotionStrategy
{
    [Header("Movement")]
    [SerializeField] private float moveSpeed = 6f;

    [Header("Ground Check")]
    [SerializeField] private Transform groundCheck;
    [SerializeField] private float groundRadius = 0.25f;
    [SerializeField] private LayerMask groundLayer;

    [Header("Animation")]
    [SerializeField] private Animator neutralAnimator;

    private Rigidbody2D rb;
    private PlayerHurtLock hurtLock;
    private PlayerStateMachine stateMachine;

    private Vector2 moveInput;

    private bool isFailing = false;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        hurtLock = GetComponent<PlayerHurtLock>();
        stateMachine = GetComponent<PlayerStateMachine>();

        ResolveNeutralAnimator();
    }

    public void Enter()
    {
        isFailing = false;

        if (CanUseNeutralAnimator())
        {
            neutralAnimator.SetFloat("speed", 0f);
            neutralAnimator.SetFloat("yVelocity", rb.linearVelocity.y);
            neutralAnimator.SetBool("isGrounded", IsGrounded());
        }
    }

    public void Exit()
    {
        if (CanUseNeutralAnimator())
        {
            neutralAnimator.SetFloat("speed", 0f);
            neutralAnimator.SetFloat("yVelocity", 0f);
            neutralAnimator.SetBool("isGrounded", true);
        }
    }

    public void HandleMove(Vector2 move)
    {
        if (isFailing)
            return;

        moveInput = move;
    }

    public void HandleJumpBreak(bool isHeld, bool pressedThisFrame, bool releasedThisFrame)
    {
        // ������ �� ���� ���� �� Space ����
    }

    public void Tick()
    {
        if (isFailing)
            return;

        bool grounded = IsGrounded();

        if (hurtLock != null && hurtLock.IsLocked)
        {
            if (CanUseNeutralAnimator())
            {
                neutralAnimator.SetFloat("speed", 0f);
                neutralAnimator.SetFloat("yVelocity", rb.linearVelocity.y);
                neutralAnimator.SetBool("isGrounded", grounded);
            }

            return;
        }

        float x = Mathf.Clamp(moveInput.x, -1f, 1f);

        rb.linearVelocity = new Vector2(x * moveSpeed, rb.linearVelocity.y);

        if (CanUseNeutralAnimator())
        {
            neutralAnimator.SetFloat("speed", Mathf.Abs(x));
            neutralAnimator.SetFloat("yVelocity", rb.linearVelocity.y);
            neutralAnimator.SetBool("isGrounded", grounded);
        }
    }

    // ���� ������ ��� �������,
    // �� �� ����� ��� Game Over �����
    public void HandleStaminaDepleted()
    {
        if (isFailing)
            return;

        isFailing = true;

        rb.linearVelocity = Vector2.zero;

        if (CanUseNeutralAnimator())
        {
            neutralAnimator.SetFloat("speed", 0f);
            neutralAnimator.SetFloat("yVelocity", 0f);
            neutralAnimator.SetBool("isGrounded", IsGrounded());
        }

        GameEvents.RaiseGameOver();
    }

    private bool IsGrounded()
    {
        if (groundCheck == null)
            return false;

        return Physics2D.OverlapCircle(groundCheck.position, groundRadius, groundLayer);
    }

    private void ResolveNeutralAnimator()
    {
        if (neutralAnimator != null)
            return;

        Transform neutralVisual = transform.Find("NeutralVisual");

        if (neutralVisual != null)
            neutralAnimator = neutralVisual.GetComponent<Animator>();
    }

    private bool CanUseNeutralAnimator()
    {
        return neutralAnimator != null &&
               neutralAnimator.isActiveAndEnabled &&
               neutralAnimator.gameObject.activeInHierarchy &&
               neutralAnimator.runtimeAnimatorController != null;
    }
}